const mongoose = require('mongoose');

const portfolioSchema = new mongoose.Schema({
  student: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Student', 
    required: true,
    unique: true
  },
  isPublic: { 
    type: Boolean, 
    default: false 
  },
  approvedBy: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Admin'
  },
  approvedAt: { 
    type: Date 
  },
  
  // Personal Information
  displayName: { 
    type: String, 
    required: true,
    trim: true
  },
  bio: { 
    type: String,
    maxlength: 500
  },
  profileImage: { 
    type: String // URL or filename
  },
  
  // Professional Links
  githubProfile: { 
    type: String,
    validate: {
      validator: function(v) {
        return !v || /^https:\/\/github\.com\/[\w-]+\/?$/.test(v);
      },
      message: 'Invalid GitHub profile URL'
    }
  },
  linkedinProfile: { 
    type: String,
    validate: {
      validator: function(v) {
        return !v || /^https:\/\/www\.linkedin\.com\/in\/[\w-]+\/?$/.test(v);
      },
      message: 'Invalid LinkedIn profile URL'
    }
  },
  portfolioWebsite: { 
    type: String,
    validate: {
      validator: function(v) {
        return !v || /^https?:\/\/.+/.test(v);
      },
      message: 'Invalid website URL'
    }
  },
  
  // Skills and Technologies
  skills: [{
    name: { type: String, required: true },
    level: { type: String, enum: ['Beginner', 'Intermediate', 'Advanced'], required: true },
    category: { type: String } // e.g., "Programming", "Framework", "Tool"
  }],
  
  // Project Showcase
  featuredProjects: [{
    title: { type: String, required: true },
    description: { type: String, required: true },
    technologies: [{ type: String }],
    githubUrl: { type: String },
    liveUrl: { type: String },
    image: { type: String }, // screenshot or demo image
    completedAt: { type: Date }
  }],
  
  // Achievements and Certifications
  achievements: [{
    title: { type: String, required: true },
    description: { type: String },
    achievedAt: { type: Date, required: true },
    certificateUrl: { type: String }, // link to certificate/badge
    issuer: { type: String } // e.g., "CodeCamp Institute"
  }],
  
  // Performance Metrics (auto-populated)
  performanceMetrics: {
    totalTasksCompleted: { type: Number, default: 0 },
    averageGrade: { type: String },
    coursesCompleted: [{ type: String }],
    ranking: { type: Number }, // position among peers
    completionRate: { type: Number }, // percentage of tasks completed on time
  },
  
  // Contact Information (optional, for public display)
  contactInfo: {
    email: { type: String },
    phone: { type: String },
    location: { type: String } // city, country
  },
  
  // SEO and Discovery
  tags: [{ type: String }], // for searchability
  category: { 
    type: String,
    ref: 'Student' // should match student's category
  },
  
  // Analytics
  viewCount: { type: Number, default: 0 },
  lastViewed: { type: Date },
  
  // Timestamps
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date },
  publishedAt: { type: Date } // when it was made public
});

// Update the updatedAt field on save
portfolioSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  
  // Set publishedAt when portfolio becomes public for the first time
  if (this.isPublic && !this.publishedAt) {
    this.publishedAt = Date.now();
  }
  
  next();
});

// Index for efficient queries
portfolioSchema.index({ isPublic: 1, category: 1 });
portfolioSchema.index({ 'performanceMetrics.ranking': 1 });
portfolioSchema.index({ publishedAt: -1 });
portfolioSchema.index({ tags: 1 });

// Method to increment view count
portfolioSchema.methods.recordView = function() {
  if (this.isPublic) {
    this.viewCount += 1;
    this.lastViewed = Date.now();
    return this.save();
  }
};

// Static method to get top performers by category
portfolioSchema.statics.getTopPerformers = function(category = null, limit = 10) {
  const query = { isPublic: true };
  if (category) query.category = category;
  
  return this.find(query)
    .populate('student', 'name studentId')
    .sort({ 'performanceMetrics.ranking': 1, publishedAt: -1 })
    .limit(limit);
};

module.exports = mongoose.model('Portfolio', portfolioSchema);
