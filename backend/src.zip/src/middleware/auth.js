const jwt = require('jsonwebtoken');
const { Admin, Student } = require('../models');
const { USER_ROLES, JWT_EXPIRY } = require('../config/constants');

// Generate JWT tokens
const generateTokens = (payload) => {
  const accessToken = jwt.sign(payload, process.env.JWT_SECRET, {
    expiresIn: JWT_EXPIRY.ACCESS_TOKEN
  });
  
  const refreshToken = jwt.sign(payload, process.env.JWT_REFRESH_SECRET, {
    expiresIn: JWT_EXPIRY.REFRESH_TOKEN
  });
  
  return { accessToken, refreshToken };
};

// Verify JWT token middleware
const verifyToken = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({
        success: false,
        message: 'Access token required'
      });
    }
    
    const token = authHeader.substring(7); // Remove 'Bearer ' prefix
    
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    
    // Attach user info to request
    req.user = decoded;
    next();
    
  } catch (error) {
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({
        success: false,
        message: 'Token expired',
        code: 'TOKEN_EXPIRED'
      });
    }
    
    return res.status(401).json({
      success: false,
      message: 'Invalid token'
    });
  }
};

// Admin authentication middleware
const requireAdmin = async (req, res, next) => {
  try {
    if (!req.user || req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Admin access required'
      });
    }
    
    // Fetch fresh admin data
    const admin = await Admin.findById(req.user.id);
    
    if (!admin || !admin.isActive) {
      return res.status(403).json({
        success: false,
        message: 'Admin account inactive'
      });
    }
    
    req.admin = admin;
    next();
    
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: 'Authentication error'
    });
  }
};

// Student authentication middleware
const requireStudent = async (req, res, next) => {
  try {
    if (!req.user || req.user.role !== 'student') {
      return res.status(403).json({
        success: false,
        message: 'Student access required'
      });
    }
    
    // Fetch fresh student data
    const student = await Student.findById(req.user.id);
    
    if (!student || !student.isActive) {
      return res.status(403).json({
        success: false,
        message: 'Student account inactive'
      });
    }
    
    req.student = student;
    next();
    
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: 'Authentication error'
    });
  }
};

// Permission-based middleware for admins
const requirePermission = (permission) => {
  return async (req, res, next) => {
    try {
      if (!req.admin) {
        return res.status(403).json({
          success: false,
          message: 'Admin authentication required'
        });
      }
      
      if (!req.admin.permissions[permission]) {
        return res.status(403).json({
          success: false,
          message: `Permission '${permission}' required`
        });
      }
      
      next();
      
    } catch (error) {
      return res.status(500).json({
        success: false,
        message: 'Permission check failed'
      });
    }
  };
};

// Refresh token middleware
const refreshAccessToken = async (req, res, next) => {
  try {
    const { refreshToken } = req.body;
    
    if (!refreshToken) {
      return res.status(401).json({
        success: false,
        message: 'Refresh token required'
      });
    }
    
    const decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET);
    
    // Generate new access token
    const payload = {
      id: decoded.id,
      role: decoded.role,
      email: decoded.email
    };
    
    const { accessToken } = generateTokens(payload);
    
    res.json({
      success: true,
      data: { accessToken }
    });
    
  } catch (error) {
    return res.status(401).json({
      success: false,
      message: 'Invalid refresh token'
    });
  }
};

module.exports = {
  generateTokens,
  verifyToken,
  requireAdmin,
  requireStudent,
  requirePermission,
  refreshAccessToken
};