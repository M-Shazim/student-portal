const express = require('express');
const router = express.Router();
const {
  adminLogin,
  studentLogin,
  logout,
  getProfile,
  changePassword
} = require('../controllers/authController');
const {
  verifyToken,
  refreshAccessToken
} = require('../middleware/auth');
const {
  adminLoginValidator,
  studentLoginValidator,
  changePasswordValidator
} = require('../validators/authValidators');

// Public routes
router.post('/admin/login', adminLoginValidator, adminLogin);
router.post('/student/login', studentLoginValidator, studentLogin);
router.post('/refresh-token', refreshAccessToken);

// Protected routes
router.use(verifyToken); // Apply to all routes below

router.post('/logout', logout);
router.get('/profile', getProfile);
router.put('/change-password', changePasswordValidator, changePassword);

module.exports = router;