const { Admin, Student } = require('../models');
const { generateTokens } = require('../middleware/auth');
const { validationResult } = require('express-validator');

// Admin login
const adminLogin = async (req, res) => {
  try {
    // Check validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }
    
    const { email, password, rememberMe } = req.body;
    console.log('Login request:', email, password);
    
    // Find admin by email
    const admin = await Admin.findOne({ email }).select('+password');
    
    if (!admin) {
      console.log('Admin not found');
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials'
      });
    }
    
    // Check if admin is active
    if (!admin.isActive) {
      return res.status(401).json({
        success: false,
        message: 'Account is inactive'
      });
    }
    
    // Verify password
    const isPasswordValid = await admin.comparePassword(password);
    console.log('Password valid?', isPasswordValid);
    
    if (!isPasswordValid) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials'
      });
    }
    
    // Generate tokens
    const payload = {
      id: admin._id,
      role: 'admin',
      email: admin.email,
      name: admin.name
    };
    
    const { accessToken, refreshToken } = generateTokens(payload);
    
    // Update last login
    admin.lastLogin = new Date();
    await admin.save();
    
    // Set HTTP-only cookie for refresh token if remember me is checked
    if (rememberMe) {
      res.cookie('refreshToken', refreshToken, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict',
        maxAge: 7 * 24 * 60 * 60 * 1000 // 7 days
      });
    }
    
    res.json({
      success: true,
      message: 'Login successful',
      data: {
        admin: admin.toJSON(),
        accessToken,
        refreshToken: rememberMe ? undefined : refreshToken // Don't send in response if using cookies
      }
    });
    
  } catch (error) {
    console.error('Admin login error:', error);
    res.status(500).json({
      success: false,
      message: 'Login failed'
    });
  }
};

// Student login
const studentLogin = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }
    
    const { studentId, password } = req.body;
    
    // Find student by studentId
    const student = await Student.findOne({ studentId }).select('+password');
    
    if (!student) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials'
      });
    }
    
    // Check if student is active
    if (!student.isActive) {
      return res.status(401).json({
        success: false,
        message: 'Account is inactive'
      });
    }
    
    // Verify password
    const isPasswordValid = await student.comparePassword(password);
    
    if (!isPasswordValid) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials'
      });
    }
    
    // Generate tokens
    const payload = {
      id: student._id,
      role: 'student',
      studentId: student.studentId,
      name: student.name,
      category: student.category
    };
    
    const { accessToken, refreshToken } = generateTokens(payload);
    
    // Update last login
    student.lastLogin = new Date();
    await student.save();
    
    res.json({
      success: true,
      message: 'Login successful',
      data: {
        student: student.toJSON(),
        accessToken,
        refreshToken
      }
    });
    
  } catch (error) {
    console.error('Student login error:', error);
    res.status(500).json({
      success: false,
      message: 'Login failed'
    });
  }
};

// Logout
const logout = async (req, res) => {
  try {
    // Clear refresh token cookie if exists
    res.clearCookie('refreshToken');
    
    res.json({
      success: true,
      message: 'Logout successful'
    });
    
  } catch (error) {
    console.error('Logout error:', error);
    res.status(500).json({
      success: false,
      message: 'Logout failed'
    });
  }
};

// Get current user profile
const getProfile = async (req, res) => {
  try {
    let user;
    
    if (req.user.role === 'admin') {
      user = await Admin.findById(req.user.id);
    } else if (req.user.role === 'student') {
      user = await Student.findById(req.user.id);
    }
    
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }
    
    res.json({
      success: true,
      data: { user: user.toJSON() }
    });
    
  } catch (error) {
    console.error('Get profile error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch profile'
    });
  }
};

// Change password
const changePassword = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }
    
    const { currentPassword, newPassword } = req.body;
    let user;
    
    // Find user based on role
    if (req.user.role === 'admin') {
      user = await Admin.findById(req.user.id).select('+password');
    } else if (req.user.role === 'student') {
      user = await Student.findById(req.user.id).select('+password');
    }
    
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }
    
    // Verify current password
    const isCurrentPasswordValid = await user.comparePassword(currentPassword);
    
    if (!isCurrentPasswordValid) {
      return res.status(400).json({
        success: false,
        message: 'Current password is incorrect'
      });
    }
    
    // Update password
    user.password = newPassword;
    await user.save();
    
    res.json({
      success: true,
      message: 'Password changed successfully'
    });
    
  } catch (error) {
    console.error('Change password error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to change password'
    });
  }
};

module.exports = {
  adminLogin,
  studentLogin,
  logout,
  getProfile,
  changePassword
};